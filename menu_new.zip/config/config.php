<?php
require_once('functions.php');


if(!defined('ROOT')){
    define('ROOT','http://'.$_SERVER['HTTP_HOST'].getFolderProyect());
}



